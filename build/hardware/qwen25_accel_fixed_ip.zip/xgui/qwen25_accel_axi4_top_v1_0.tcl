# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "AXIL_AW" -parent ${Page_0}
  ipgui::add_param $IPINST -name "AXIL_DW" -parent ${Page_0}
  ipgui::add_param $IPINST -name "RS_LV" -parent ${Page_0}


}

proc update_PARAM_VALUE.AXIL_AW { PARAM_VALUE.AXIL_AW } {
	# Procedure called to update AXIL_AW when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AXIL_AW { PARAM_VALUE.AXIL_AW } {
	# Procedure called to validate AXIL_AW
	return true
}

proc update_PARAM_VALUE.AXIL_DW { PARAM_VALUE.AXIL_DW } {
	# Procedure called to update AXIL_DW when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AXIL_DW { PARAM_VALUE.AXIL_DW } {
	# Procedure called to validate AXIL_DW
	return true
}

proc update_PARAM_VALUE.RS_LV { PARAM_VALUE.RS_LV } {
	# Procedure called to update RS_LV when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.RS_LV { PARAM_VALUE.RS_LV } {
	# Procedure called to validate RS_LV
	return true
}


proc update_MODELPARAM_VALUE.AXIL_AW { MODELPARAM_VALUE.AXIL_AW PARAM_VALUE.AXIL_AW } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AXIL_AW}] ${MODELPARAM_VALUE.AXIL_AW}
}

proc update_MODELPARAM_VALUE.AXIL_DW { MODELPARAM_VALUE.AXIL_DW PARAM_VALUE.AXIL_DW } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AXIL_DW}] ${MODELPARAM_VALUE.AXIL_DW}
}

proc update_MODELPARAM_VALUE.RS_LV { MODELPARAM_VALUE.RS_LV PARAM_VALUE.RS_LV } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.RS_LV}] ${MODELPARAM_VALUE.RS_LV}
}

